# SUMO Challenge Data Description

## Input Format
The official SUMO input format is an RGB-D image represented as a cubemap. Here is a sample SUMO input file. The cubemap is stored in a multi-page TIFF file(**sumo-input.tif**), with the color image and the depth image stored separately. Each image is 6K x 1K (6144 x 1024) pixels in size. The cube-map faces are stored in the following order: back, left, front, right, top, bottom. Each face is 1K x 1K (1024 x 1024) pixels (i.e., side length = 1024).

The color image is stored with 8 bits per color channel, in RGB order.

The range image is stored as unsigned 16 bit integers using inverse values. A value of 0 represents infinity (i.e., unknown range), and a maximum value (2^16-1) represents the minimum distance, which is 0.3 meters.

Range values are converted to 3D using a standard pinhole model with a focal length of 512 (0.5 x side length) and image center at (512, 512).

In addition to the official RGBD input, we also provide optional category and instance images for assisting in training. Pixels in the category image are integer values corresponding to element category IDs as described below. Pixels in the instance image are integer values also. An instance of an object (i.e., a chair) is assigned a unique instance ID, which matches the ID of the corresponding element in the ground truth scene. Category and instance images are not provided for evaluation scenes, and your algorithm is expected to operate without the need for these images at test time.

The multi-page TIFF contains these four images in the following order:

1. RGB
2. range
3. category
4. instance

## Output Format
The SUMO output format is a directory containing an xml file(**sumo-output.xml**) and, for the voxel and mesh performance tracks, a set of additional files describing the element geometry. The format of the xml is specified by an xsd file (**scene_format_spec.xsd**). For the voxel track, the elements are represented by voxel grids in **hdf5** format, each in a separate file. For the mesh track, the elements are represented by textured meshes in **glb** format. (Note that glb is the binary version of glTF).

## Categories
The categories for the SUMO challenge elements are a subset of those in the SUNCG fine-grained class list. The file **categories.csv** provides the list of categories with suggested display colors, and a boolean indicating whether the category is used for evaluation in the SUMO challenge.